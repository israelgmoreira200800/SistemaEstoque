import { redirect } from "next/navigation";

export default function CatalogRedirectPage() {
  redirect("/dashboard/itens");
}

